#ifndef REDES_P3_GETIP2_H
#define REDES_P3_GETIP2_H

#include <stdlib.h>

char *get_local_ip_addresses(char* local_ip_addresses_string, size_t len, int family_to_request);

#endif //REDES_P3_GETIP2_H
